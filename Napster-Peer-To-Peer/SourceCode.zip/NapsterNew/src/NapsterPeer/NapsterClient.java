
package NapsterPeer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import IndexingServer.NapsterIndexServerIF;
/*
 * NetworkClient Implementation of NetworkClientInterface 
 * Implementing all the methods declared in NetworkClientInterface 
 * also it defines its own methods and performs the Operations needed on the Client Side
 * like Downloading the file on Peer Side, searching the file over PeerToPeer network,
 * responseTime taken while downloading the file 
 */
public class NapsterClient extends UnicastRemoteObject implements NapsterClientInterface, Runnable { 
	private static final long serialVersionUID = 1L;
	private NapsterIndexServerIF peerServer;
	private String clientName = null;
	private String client_port_no;
	String filename_1;
	private String clientDirPath = null;
	private String[] files;
	
	protected NapsterClient() throws RemoteException {
		super();
	}
	
	protected NapsterClient(String name,String  port_no, NapsterIndexServerIF peerServer) throws RemoteException {
		this.clientName = name;
		this.peerServer = peerServer;
    		this.client_port_no=port_no;
		//create list of files in peer root directory
		try{
			//get peer root directory pathname
			this.clientDirPath = System.getProperty("user.dir");
		    System.out.print("Peer Directory is: "+clientDirPath.replace("\\", "/")+"\n");
		    //get all files in peer root directory
			File f = new File(clientDirPath);
			this.files = f.list();	//returns directory and files (with extension) in directory			
		}catch (Exception e){
		    System.out.println("Peer path Exception caught ="+e.getMessage());
		}		
		//register peer data structure, including files array
		System.out.println(peerServer.registerClientinP2P(this));
		new Thread(new NapsterDirectoryLis(this)).start();
	}
	
	public String getPeerName() {
		return clientName;
	}
	public String[] getFilesArray() {
		return files;
	}
	public String getClientDirectory() {
		return clientDirPath;
	}
	public NapsterIndexServerIF getPeerServer() {
		return peerServer;
	}
	public String getPeerport_no()
	{
		return client_port_no;
	}
	/**
	 *Updating the index server when the peer is added along with its files 
         **/
	public synchronized void updateIndexServer() throws RemoteException {
		//get all files in peer root directory
		File file = new File(clientDirPath);
		this.files = file.list();	//returns directory and files (with extension) in directory
		if(peerServer.updatePeerInP2P(this)){
			System.out.println("Index Server has been updated....");
		} else {
			System.out.println("Sorry,,,,Something went wrong while updating the Index Server");
		}		
	}
	/**
	 * starts the new thread every time when the Peer is registered to the index Server
	 */
	public void run() {
		
		Scanner commandLine = new Scanner(System.in);
		String cmd, taskName, filename;
		System.out.println("||        Peer to Peer File Sharing System      ||");
		System.out.println("||==============================================||");
		System.out.println("||   What Operations whould you like to perform ||");
		System.out.println("Enter The Option and filename:\n----------------\n1. Downloading From Index Server \n \n2. Exit\n");	
		while (true) {	
			cmd = commandLine.nextLine();
			CharSequence symbol = " ";
			// Command Line Arguments for entering the Options 
			if (cmd.contains(symbol)) {
				taskName = cmd.substring(0, cmd.indexOf(' '));
				filename = cmd.substring(cmd.indexOf(' ')+1);
				filename_1=filename;
				if(Arrays.asList(this.getFilesArray()).contains(filename)) 
					{
					System.out.println("Please enter the Valid file Name");
					continue;
					}
				if (taskName.equals("1") || taskName.equals('d')) {
					NapsterClientInterface[] peer = findFile(filename);
					int choice = commandLine.nextInt();
					String peerServerURL;
					NapsterClientInterface peerClientServer = null;
					NapsterClientServerIF peerclientserverif = null;
					try {
						String peerUrl = "rmi://localhost:"+peer[choice-1].getPeerport_no()+"/clientserver";
						peerclientserverif= (NapsterClientServerIF) Naming.lookup(peerUrl);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NotBoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					downloadFilefromServer(peerclientserverif, filename);
				} else {
					System.out.println("Usage: <task> <item>");
				}
				try {
					responsetime();
				} catch (RemoteException | MalformedURLException | NotBoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	private void downloadFilefromServer(NapsterClientServerIF peerWithFile, String filename) {
		
		try {
			if(peerWithFile.sendFilefromOnePeertoOther(this,filename)){
				System.out.println("File Downloaded");
				//updateServer();
			} else {
				System.out.println(" File could not be downloaded");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	/**
	 *findFile() does the downloading of the file from the Other peer over P2P network
	 */
	public synchronized NapsterClientInterface[] findFile(String filename) {
		System.out.println("Do you want to download the file?: "+filename);
		NapsterClientInterface[] peerClient;	//peer client that contains file
		try {
			//returns a peer with file
			peerClient = peerServer.fileSearchP2P(filename, clientName);
			if (peerClient != null) {
				//list peers with file
				System.out.println("Following Peers have your file.:");
				for (int i=0; i<peerClient.length; i++) {
					if (peerClient[i] != null)
						System.out.println((i+1)+". "+peerClient[i].getPeerName());
				}
				
				System.out.println("Enter the number matching the Peer you will like to download from");
				return peerClient;
			} else {
				System.out.println("No Peer has your file.");
			}
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		return null;		
	}
	/**
         *acceptclientFile() method : Accepts the file from the other peer and storing it to the requested peer's directory
        **/
	public synchronized boolean acceptclientFile(String fileName, byte[] data, int len) throws RemoteException{
		System.out.println("Your File is Downloading......! Please wait for the moment!!!!");
        try{
        	File newFile=new File(fileName);
        	newFile.createNewFile();
        	FileOutputStream fileOut=new FileOutputStream(newFile,true);
        	fileOut.write(data,0,len);
        	fileOut.flush();
        	fileOut.close();
        }catch(Exception e){
        	e.printStackTrace();
        }
		return true;
	}

	/**
	 * responsetime() method is used to calculate the response time from the index server
         * to peer for searching of the file
	 */
	public void responsetime() throws RemoteException, MalformedURLException, NotBoundException{
		long responseTime=0;
		long endTime=0;
		String filename=filename_1;
		NapsterClientInterface[] peer;
				for(int i=0;i<1000;i++)
				{
					long startTime = System.currentTimeMillis();
					try {
						peer = peerServer.fileSearchP2P(filename, clientName);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 endTime = System.currentTimeMillis()-startTime;
					responseTime = responseTime+endTime;
				}
				System.out.println("Average response time of a Peer "+this.getPeerName()+" is " + responseTime/1000.000 + "ms");
	}
}
