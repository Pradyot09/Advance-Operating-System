/**
 * Peer interface declaring the methods 
 * needed by the PeerClient such as its port no, its root Directory,
 * its files, peers name
 
 **/
package NapsterPeer;

import java.rmi.Remote;
import java.rmi.RemoteException;

import IndexingServer.NapsterIndexServerIF;

public interface NapsterClientInterface extends Remote {
	String[] getFilesArray() throws RemoteException;
	String getPeerName() throws RemoteException;
	String getClientDirectory() throws RemoteException;
	public String getPeerport_no() throws RemoteException;
	NapsterIndexServerIF getPeerServer() throws RemoteException;
	void updateIndexServer() throws RemoteException;
	boolean acceptclientFile(String name, byte[] mydata, int mylen) throws RemoteException;
}
