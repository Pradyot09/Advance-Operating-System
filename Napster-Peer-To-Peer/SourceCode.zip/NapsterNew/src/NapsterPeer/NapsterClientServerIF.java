
package NapsterPeer;
/**
 * @author Nilesh Jorwar
 * ClientServerInterface declaration for communication between Peers for sending file to each other 
 */
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NapsterClientServerIF  extends Remote{
	public String getClientName() throws RemoteException;
	boolean sendFilefromOnePeertoOther(NapsterClientInterface peerClient, String filename) throws RemoteException;
}
