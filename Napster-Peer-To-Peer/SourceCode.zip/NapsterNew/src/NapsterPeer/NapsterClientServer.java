
package NapsterPeer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
/**
 NapsterClientServer Implementation
 ClientServerInterface implementation for sending files between peers
 */
public class NapsterClientServer extends UnicastRemoteObject implements NapsterClientServerIF {

	protected NapsterClientServer() throws RemoteException {
		super();
	}
	@Override
	public String getClientName() throws RemoteException {
		
		return "Pradyot Mayank";
	}
	/**
         * Sending the file to Requesting peer by converting it into the FileStream
	 */
	public synchronized boolean sendFilefromOnePeertoOther(NapsterClientInterface c, String file) throws RemoteException{
		
		 try{
			 File f2 = new File(file);			 
			 FileInputStream filein = new FileInputStream(f2);			 				 
			 byte[] my_data = new byte[1024*1024];						
			 int lenght_file = filein.read(my_data);
			 while(lenght_file>0){
				 if(c.acceptclientFile(f2.getName(), my_data, lenght_file)){
					 System.out.println("File '"+file+"' has been send to the requested Peer: "+c.getPeerName());
					 lenght_file = filein.read(my_data);
				 } else {
					 System.out.println("Sorry: File is not  sent");
				 }				 
			 }
		 }catch(Exception e){
			 e.printStackTrace();
			 
		 }
		
		return true;
	}
}