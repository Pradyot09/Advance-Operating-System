
package NapsterPeer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import IndexingServer.NapsterIndexServerIF;
/**
 NapsterClientDriver Implementation
 used for multi threading of the clients registering with the index server 
 */
public class NapsterClientDriver {
	private static final String INDEX_SERVER = "localhost";
	static String arg=null;
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		if (args.length == 3) {
                    //link server and client
                    arg=args[1];
			
			String indexServerUrl = "rmi://"+INDEX_SERVER+":"+args[0]+"/peerserver";
			NapsterIndexServerIF peerServer = (NapsterIndexServerIF) Naming.lookup(indexServerUrl);
			NapsterClient clientserver= new NapsterClient(args[2],args[1],peerServer);
			new Thread(new peerclientserver()).start();
			new Thread(clientserver).start();		
		} else {
			System.err.println("Usage: PeerClientDriver <port_no> <Peer_name>");
		}
	}
	static class peerclientserver implements Runnable
	{
		public void run()
		{			
			try {
				String clientURL = "rmi://"+INDEX_SERVER+":"+arg+"/clientserver";
				NapsterPeer.NapsterClientServerIF pcs = new NapsterClientServer();
				Naming.rebind(clientURL,pcs);
			} catch (RemoteException | MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
