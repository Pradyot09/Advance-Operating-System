package IndexingServer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;

/**
 * This is the Main class on the Server side which 
 * binds the Server with the Port using rebind() method
 * and registers it with the naming registry
 */

public class NapsterIndexServerDriver {
	public static void main(String[] args) throws RemoteException, MalformedURLException {
		System.setProperty("java.rmi.server.hostname","localhost");		//192.168.107.1
		NapsterIndexServer peerserver = new NapsterIndexServer();
		Naming.rebind("rmi://localhost:"+args[0]+"/peerserver",peerserver);
    		System.out.println("                                                                              ");
		System.out.println("                           PEER-TO-PEER FILE SHARING SYSTEM                 ||");
		System.out.println("                       ========================================             ||");
		System.out.println("                                                                               ");
		System.out.println("                      <CENTRAL INDEX SERVER IS UP AND RUNNING>                ");
		System.out.println("||==========================================================================||");
	}
	
}
