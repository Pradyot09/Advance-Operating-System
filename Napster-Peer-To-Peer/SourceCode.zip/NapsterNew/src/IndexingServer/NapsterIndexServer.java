package IndexingServer;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import NapsterPeer.NapsterClientInterface;

/**
 This implementation class of interface
 NapsterIndexServerIF implements all the methods declared in
 NapsterIndexServerIF It provides methods for peers to register with
 the index server, display all the registered peers and search the files
 requested by peer
 *
 */
public class NapsterIndexServer extends UnicastRemoteObject implements NapsterIndexServerIF {

    //private static final long serialVersionUID = 1L;

    private ArrayList<NapsterClientInterface> peersIf = new ArrayList<NapsterClientInterface>();

    protected NapsterIndexServer() throws RemoteException {
        super();
    }
    /**
     * registerClientinP2P() method is used to register the 
 peer with the index server along with its files logged onto the server
     
     **/
    public synchronized String registerClientinP2P(NapsterClientInterface requestingClient) throws RemoteException {
        peersIf.add(requestingClient);
        String ListFile = "";
        String[] filesFromPeerArry = requestingClient.getFilesArray();
        for (int i = 0; i < filesFromPeerArry.length; i++) {
            ListFile += "\n\t- " + filesFromPeerArry[i];
        }
        System.out.println("\n\n Added the New Peer whose name is......"+requestingClient.getPeerName());
        RegisteredClient();
        return "New Peer '" + requestingClient.getPeerName() + "' has registered with index server and has indexed the following files" + ListFile;
    }

    public boolean updatePeerInP2P(NapsterClientInterface peerClient) throws RemoteException {
        for (int l = 0; l < peersIf.size(); l++) {
            if (peerClient.getPeerName().equals(peersIf.get(l).getPeerName())) {
                peersIf.remove(l);
                peersIf.add(peerClient);
            }
        }
        System.out.println("\n\nServer has been updated. ");
        RegisteredClient();
        return true;
    }
/**
 * showRegisteredClientsOfPeerToPeerCommunication() method 
 * displays those peers that registered with Index Server
 * 
 
 **/
    private void RegisteredClient() throws RemoteException {
        System.out.println("Welcome to the World of PeerswList........");
        for (int l = 0; l < peersIf.size(); l++) {
            System.out.println("Find the Peer Information below .................");
            System.out.println("Peer Name: " + peersIf.get(l).getPeerName());
            System.out.println("Peer Root Directory: " + peersIf.get(l).getClientDirectory());
            System.out.println("Associated Files: ");
            String[] filelist = peersIf.get(l).getFilesArray();
            for (int a = 0; a < filelist.length; a++) {
                System.out.println("\t" + filelist[a]);
            }
        }
    }
/**
 * fileSearchP2P() method used by the Peer to search for the file over the Peer to Peer
 network and gives the requesting peer the file if available to the rest of the 
 peers indexed with the Server
 
 **/
    public synchronized NapsterClientInterface[] fileSearchP2P(String fileName, String requestingPeerClient) throws RemoteException {
        System.out.println("\nRegistred Peer '" + requestingPeerClient + "' is requesting a file named as ---"+fileName);
        Boolean filefoundFlag = false;
        NapsterClientInterface[] peerInterface = new NapsterClientInterface[peersIf.size()];
        int count = 0;
        System.out.println("\n Wait Index Server is searching your File.......");
        for (int l = 0; l < peersIf.size(); l++) {
            String[] filelist = peersIf.get(l).getFilesArray();
            for (int a = 0; a < filelist.length; a++) {
                if (fileName.equals(filelist[a])) {
                    filefoundFlag = true;
                    peerInterface[count] = (NapsterClientInterface) peersIf.get(l);
                    count++;
                }
            }
        }
        if (filefoundFlag) {
            System.out.println("From the List of Peers '" + fileName + "' , is about to start sending to  " + requestingPeerClient);
            return peerInterface;
        } else {
            System.out.println("Ohh Sorry.......\n The file: '" + fileName + "' is not present at any Peer");
        }
        return null;
    }
}
