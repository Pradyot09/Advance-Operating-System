package IndexingServer;
import java.rmi.Remote;
import java.rmi.RemoteException;

import NapsterPeer.NapsterClientInterface;

/**
 * @author Nilesh Jorwar 
 * This is the Interface declaring the Methods that will be 
 * invoked by peer to interact with the index server
 * 
 *
 */
public interface NapsterIndexServerIF extends Remote {
	String registerClientinP2P(NapsterClientInterface peerClient) throws RemoteException;
	NapsterClientInterface[] fileSearchP2P(String file, String requestingPeer) throws RemoteException;
	boolean updatePeerInP2P(NapsterClientInterface peerClient) throws RemoteException;
}
